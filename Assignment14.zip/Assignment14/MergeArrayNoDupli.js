function mergeArrays(arr1, arr2) {
    let mergedArr = [...arr1, ...arr2];
    let uniqueArr = [...new Set(mergedArr)];
    return uniqueArr;
}
