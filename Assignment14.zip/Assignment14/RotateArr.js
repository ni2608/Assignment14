function rotateArray(arr, k) {
    let n = arr.length;
    k = k % n; // In case k is greater than the array length
    let rotatedArr = arr.slice(n - k).concat(arr.slice(0, n - k));
    return rotatedArr;
}
