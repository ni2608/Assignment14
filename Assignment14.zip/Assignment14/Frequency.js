function findFrequency(arr) {
    let frequency = {};
    for (let num of arr) {
        frequency[num] = (frequency[num] || 0) + 1;
    }
    return frequency;
}
