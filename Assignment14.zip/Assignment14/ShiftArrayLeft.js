function shiftLeft(arr) {
    let shiftedArr = arr.slice(1);
    shiftedArr.push(arr[0]);
    return shiftedArr;
}
